const Kafka = require('node-rdkafka')


document.getElementById('sendMessage').addEventListener('click', () => {
  const messageField = document.getElementById('message')
  const message = messageField.value
  let msgReturn = ''
  
  document.getElementById('result').innerHTML = 'Stating...'

  const topicName = document.getElementById('kafkaTopicName').value
  const groupId = document.getElementById('kafkaGroupId').value
  const kafkaServer = document.getElementById('kafkaServer').value
  const krbPrincipal = document.getElementById('krbPrincipal').value
  const krbKeytab = document.getElementById('krbKeytab').value
  const cacerts = document.getElementById('cacerts').value

  var producer = new Kafka.Producer({
    'client.id': groupId,
    'metadata.broker.list': kafkaServer,
    'security.protocol': 'SASL_SSL',
    'sasl.kerberos.service.name': 'kafka',
    'sasl.mechanism': 'GSSAPI',
    'sasl.kerberos.principal': krbPrincipal,
    'sasl.kerberos.keytab': krbKeytab,
    'ssl.ca.location': cacerts,
  });

  producer.on('event.log', function (log) {
    document.getElementById('result').innerHTML = document.getElementById('result').innerHTML + '<br/>' + 'Log: ' + log
  });

  //logging all errors
  producer.on('event.error', function (err) {
    document.getElementById('result').innerHTML = document.getElementById('result').innerHTML + '<br/>' + 'Error from producer'
    document.getElementById('result').innerHTML = document.getElementById('result').innerHTML + '<br/>' + err
  });

  producer.on('delivery-report', function (err, report) {
    msgReturn = JSON.stringify(report)
  });

  producer.on('ready', function (arg) {
    document.getElementById('result').innerHTML = document.getElementById('result').innerHTML + '<br/>' + 'producer disconnected. ' + JSON.stringify(arg)

    for (var i = 0; i < maxMessages; i++) {
      var value = Buffer.from('value-' + i);
      var key = "key-" + i;
      // if partition is set to -1, librdkafka will use the default partitioner
      var partition = -1;
      var headers = [
        { header: "header value" }
      ]
      producer.produce(topicName, partition, value, key, Date.now(), "", headers);
    }

    //need to keep polling for a while to ensure the delivery reports are received
    var pollLoop = setInterval(function () {
      producer.poll();
      if (counter === maxMessages) {
        clearInterval(pollLoop);
        producer.disconnect();
      }
    }, 1000);

    document.getElementById('result').innerHTML = message
    document.getElementById('msgError').innerHTML = msgReturn
  });

  producer.on('disconnected', function (arg) {
    document.getElementById('result').innerHTML = document.getElementById('result').innerHTML + '<br/>' + 'producer disconnected. ' + JSON.stringify(arg)
  });

  //starting the producer
  producer.connect();
})